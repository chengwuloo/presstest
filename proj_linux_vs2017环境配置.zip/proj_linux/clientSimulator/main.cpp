#include <cstdio>
#include <cstdlib>
#include <string.h>
#include <pthread.h>
#include <cstdlib>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <map>
#include <unistd.h>
#include <vector>
#include "Thread.h"
#include "sockets.h"
#include "Log.h"

#include "sys/epoll.h"

#include "Channel.h"
#include "Poller.h"
#include "Polling.h"
#include "Connector.h"
#include "PollingThread.h"

#include "Channel.h"
#include "Poller.h"
#include "Polling.h"
#include "Connector.h"
#include "PollingThread.h"
#include "TCPClient.h"

//�ͻ���
int main()
{
	Log::instance()->set_level(LVL_DEBUG);

	Log::instance()->set_level(LVL_DEBUG);
	PollingThread eventloop;
	eventloop.start();

	//while (1) {
	//	getchar();
		TCPClient c1("");
		c1.connectTCP(eventloop.ownerPolling(), Address("127.0.0.1:123458", AF_INET), true);
	//}
	
	eventloop.join(NULL);
	return 0;
}