#include "MyDll.h"
#include <stdio.h>
#include <stdlib.h>


int DllAdd(int a, int b) {
	printf("----- 2w324  THIS IS THE Newest  DllAdd : a=%d b=%d\n", a, b);
	return a + b;
}
