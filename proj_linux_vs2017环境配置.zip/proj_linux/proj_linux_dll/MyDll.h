#ifndef _MYDLL_H_INCLUDE_
#define _MYDLL_H_INCLUDE_

#ifdef __cplusplus
extern "C" {
#endif

int DllAdd(int a, int b);

#ifdef __cplusplus
}
#endif

#endif
