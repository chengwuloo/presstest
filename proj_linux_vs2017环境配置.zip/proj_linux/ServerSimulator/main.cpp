#include <cstdio>
#include <cstdlib>
#include <string.h>
#include <pthread.h>
#include <cstdlib>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <map>
#include <unistd.h>
#include <vector>
#include "Thread.h"
#include "sockets.h"
#include "Log.h"

#include "sys/epoll.h"

#include "Channel.h"
#include "Poller.h"
#include "Polling.h"
#include "Acceptor.h"
#include "PollingThread.h"
#include "TCPServer.h"

//�����
int main()
{
	Log::instance()->set_level(LVL_DEBUG);
	PollingThread eventloop;
	eventloop.start();
	TCPServer s1("");
	s1.listenTCP(eventloop.ownerPolling(), Address("127.0.0.1:12345",AF_INET));
	TCPServer s2("");
	s2.listenTCP(eventloop.ownerPolling(), Address("127.0.0.1:123458", AF_INET));
	eventloop.join(NULL);
	return 0;
}